( function( api ) {

	// Extends our custom "theta" section.
	api.sectionConstructor['theta'] = api.Section.extend( {

		// No events for this type of section.
		attachEvents: function () {},

		// Always make the section active.
		isContextuallyActive: function () {
			return true;
		}
	} );

} )( wp.customize );
