<div class="sidebar theta-sidebar">   
    <?php if ( is_active_sidebar( 'sidebar' ) ) : ?>
            <?php dynamic_sidebar( 'sidebar' ); ?>
    <?php endif; ?>                    
 
</div><!--siedbar end-->