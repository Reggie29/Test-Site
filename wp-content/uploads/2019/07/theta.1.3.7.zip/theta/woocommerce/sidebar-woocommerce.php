<div class="sidebar theta-sidebar">   

    <?php if ( is_active_sidebar( 'sidebar-woocommerce' ) ) : ?>
            <?php dynamic_sidebar( 'sidebar-woocommerce' ); ?>
    <?php endif; ?>                    
 
</div><!--siedbar end-->